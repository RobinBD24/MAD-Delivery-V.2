<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        Schema::create('roles', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique(); // super_admin, management, branch_manager, accounts, marketing, rider, customer
            $table->string('slug')->unique();
            $table->text('permissions')->nullable(); // JSON array
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('roles'); }
};
