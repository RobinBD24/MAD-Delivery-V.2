<?php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class Authenticate
{
    public function handle(Request $request, Closure $next, ...$guards)
    {
        if (!auth()->check()) {
            return redirect('/login');
        }
        return $next($request);
    }
}
