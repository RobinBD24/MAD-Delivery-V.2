<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
class NotificationController extends Controller
{
    public function index() { return response()->json(['notifications' => []]); }
    public function markRead($id) { return response()->json(['status' => 'read']); }
}
